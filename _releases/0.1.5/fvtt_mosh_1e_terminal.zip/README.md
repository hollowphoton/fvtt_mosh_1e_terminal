## Mothership Terminal Compendium | 1e | FoundryVTT
![image](https://github.com/hollowphoton/fvtt_mosh_1e_psg/assets/17795348/a1abe5c5-94d0-4d4f-9581-ac2c0fded6b0)

This is a supplemental compendium for the Mothership RPG that I use in my personal game. It defines items outside the scope of the official books. So far, this is all pet related!

#### Features
- 6 Pet Skills
- 18 Pets

#### Installation
 1. Load up Foundry VTT and go to the Add-On Modules tab
 2. Click Install Module
 3. Paste this URL into the Manifest URL field: https://github.com/hollowphoton/fvtt_mosh_1e_terminal/releases/latest/download/module.json
 4. Hit Install
 5. In a world that uses v0.4.0 (or later) of the unofficial MoSh system, go to Settings
 6. Click on Manage Modules
 7. Check the box next to this Module
 8. Click Save Module Settings
 9. You can now find this content in the compendium
